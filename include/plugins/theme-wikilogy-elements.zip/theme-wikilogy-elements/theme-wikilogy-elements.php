<?php
/**
* Plugin Name: Wikilogy Theme: Elements
* Plugin URI: http://themeforest.net/user/gloriathemes
* Description: Wikilogy elements plugin.
* Version: 1.0
* Author: Gloria Themes
* Author URI: http://gloriathemes.com/
*/



/*======
*
* Create Social Media Links for User Profiles
*
======*/
function wikilogy_user_profile_social_media( $user_profile_create_fields ) {
	$user_profile_create_fields['facebook'] = esc_html__( 'Facebook', 'wikilogy' );
	$user_profile_create_fields['googleplus'] = esc_html__( 'Google+', 'wikilogy' );
	$user_profile_create_fields['instagram'] = esc_html__( 'Instagram', 'wikilogy' );
	$user_profile_create_fields['linkedin'] = esc_html__( 'LinkedIn', 'wikilogy' );
	$user_profile_create_fields['vine'] = esc_html__( 'Vine', 'wikilogy' );
	$user_profile_create_fields['twitter'] = esc_html__( 'Twitter', 'wikilogy' );
	$user_profile_create_fields['pinterest'] = esc_html__( 'Pinterest', 'wikilogy' );
	$user_profile_create_fields['youtube'] = esc_html__( 'YouTube', 'wikilogy' );
	$user_profile_create_fields['behance'] = esc_html__( 'Behance', 'wikilogy' );
	$user_profile_create_fields['deviantart'] = esc_html__( 'DeviantArt', 'wikilogy' );
	$user_profile_create_fields['digg'] = esc_html__( 'Digg', 'wikilogy' );
	$user_profile_create_fields['dribbble'] = esc_html__( 'Dribbble', 'wikilogy' );
	$user_profile_create_fields['flickr'] = esc_html__( 'Flickr', 'wikilogy' );
	$user_profile_create_fields['github'] = esc_html__( 'GitHub', 'wikilogy' );
	$user_profile_create_fields['lastfm'] = esc_html__( 'Last.fm', 'wikilogy' );
	$user_profile_create_fields['reddit'] = esc_html__( 'Reddit', 'wikilogy' );
	$user_profile_create_fields['soundcloud'] = esc_html__( 'SoundCloud', 'wikilogy' );
	$user_profile_create_fields['tumblr'] = esc_html__( 'Tumblr', 'wikilogy' );
	$user_profile_create_fields['vimeo'] = esc_html__( 'Vimeo', 'wikilogy' );
	$user_profile_create_fields['vk'] = esc_html__( 'VK', 'wikilogy' );
	$user_profile_create_fields['medium'] = esc_html__( 'Medium', 'wikilogy' );
	$user_profile_create_fields['wikipedia'] = esc_html__( 'Wikipedia', 'wikilogy' );
	return $user_profile_create_fields;
}
add_filter( 'user_contactmethods', 'wikilogy_user_profile_social_media', 10, 1 );



/*======
*
* Comment List Template
*
======*/
function wikilogy_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	extract($args, EXTR_SKIP);

	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
?>
	<<?php echo esc_attr( $tag ) ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	
	<?php if ( 'div' != $args['style'] ) { ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
	<?php } ?>
		<div class="comment-image">
			<?php $user = get_user_by( 'email', $comment->comment_author_email ); ?>
			<?php if ( $args['avatar_size'] != 0 ) { echo get_avatar( $comment, $args['avatar_size'] ); } ?>
		</div>

		<div class="comment-content">
			<div class="comment-author">
				<?php
					$author_control = get_comment_author();
					if( !empty( $author_control ) ) {
						echo get_comment_author(); 
					}
				?>
			</div>

			<?php if ( $comment->comment_approved == '0' ) { ?>
				<p class="moderation-message"><?php echo esc_html__( 'Your comment is awaiting moderation.', 'wikilogy' ); ?></p>
			<?php } ?>

			<?php comment_text(); ?>

			<div class="comment-info">
				<div class="item comment-meta commentmetadata">
					<i class="far fa-clock"></i>
					<a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
						<?php printf( esc_html__( '%1$s', 'wikilogy' ), get_comment_date(), get_comment_time() ); ?>
					</a>
				</div>
				
				<?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'], 'before' => '<div class="item reply"><i class="far fa-comment"></i>', 'after' => '</div>' ) ) ); ?>
				
				<?php edit_comment_link( esc_html__( 'Edit', 'wikilogy' ), '<div class="item edit"><i class="fas fa-pencil-alt"></i>', '</div>' ); ?>
			</div>
		</div>

	<?php if ( 'div' != $args['style'] ) { ?>
		</div>
	<?php } ?>
<?php
}



/*======
*
* Post Types
*
======*/
	/*====== Contents ======*/
	if ( ! function_exists('wikilogy_contents') ) {
		function wikilogy_contents() {
			$labels = array(
				'name' => _x( 'Contents', 'Contents General Name', 'wikilogy' ),
				'singular_name' => _x( 'Content', 'Contents Singular Name', 'wikilogy' ),
				'menu_name' => esc_html__( 'Contents', 'wikilogy' ),
				'parent_item_colon' => esc_html__( 'Parent Content:', 'wikilogy' ),
				'all_items' => esc_html__( 'All Contents', 'wikilogy' ),
				'view_item' => esc_html__( 'View Content', 'wikilogy' ),
				'add_new_item' => esc_html__( 'Add New Content Item', 'wikilogy' ),
				'add_new' => esc_html__( 'Add New Content', 'wikilogy' ),
				'edit_item' => esc_html__( 'Edit Content', 'wikilogy' ),
				'update_item' => esc_html__( 'Update Content', 'wikilogy' ),
				'search_items' => esc_html__( 'Search Content', 'wikilogy' ),
				'not_found' => esc_html__( 'Not Content Found', 'wikilogy' ),
				'not_found_in_trash' => esc_html__( 'Not Content Found in Trash', 'wikilogy' ),
			);
			$args = array(
				'label' => esc_html__( 'Contents', 'wikilogy' ),
				'description' => esc_html__( 'Content post type description.', 'wikilogy' ),
				'labels' => $labels,
				'supports' => array( 'title', 'comments', 'author', 'excerpt', 'thumbnail', 'revisions', 'editor', 'custom-fields', 'post-formats' ),
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'show_in_nav_menus' => true,
				'show_in_admin_bar' => true,
				'menu_position' => 20,
				'menu_icon' => 'dashicons-book-alt',
				'can_export' => true,
				'rewrite' => true,
				'has_archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'capability_type' => 'post',
			);
			register_post_type( 'content', $args );
		}
		add_action( 'init', 'wikilogy_contents', 0 );
	}



/*======
*
* Taxonomies
*
======*/
	/*====== Content Tags ======*/
	if ( ! function_exists( 'content_tag' ) ) {
		function content_tag() {
			$labels = array(
				'name' => _x( 'Tags', 'Tags General Name', 'wikilogy' ),
				'singular_name' => _x( 'Tags', 'Tags Singular Name', 'wikilogy' ),
				'menu_name' => esc_html__( 'Tags', 'wikilogy' ),
				'all_items' => esc_html__( 'All Tags', 'wikilogy' ),
				'parent_item' => esc_html__( 'Parent Tag', 'wikilogy' ),
				'parent_item_colon' => esc_html__( 'Parent Tag:', 'wikilogy' ),
				'new_item_name' => esc_html__( 'New Tag Name', 'wikilogy' ),
				'add_new_item' => esc_html__( 'Add New Tag', 'wikilogy' ),
				'edit_item' => esc_html__( 'Edit Tag', 'wikilogy' ),
				'view_item' => esc_html__( 'View Tag', 'wikilogy' ),
				'update_item' => esc_html__( 'Update Tag', 'wikilogy' ),
				'separate_items_with_commas' => esc_html__( 'Separate tags with commas', 'wikilogy' ),
				'search_items' => esc_html__( 'Search Tags', 'wikilogy' ),
				'add_or_remove_items' => esc_html__( 'Add or remove tags', 'wikilogy' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used tags', 'wikilogy' ),
				'not_found' => esc_html__( 'Not Found', 'wikilogy' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
			);
			register_taxonomy( 'content_tag', array( 'content' ), $args );

		}
		add_action( 'init', 'content_tag', 0 );
	}



	/*====== Content Letters ======*/
	if ( ! function_exists( 'content_letter' ) ) {
		function content_letter() {
			$labels = array(
				'name' => _x( 'Letters', 'Letters General Name', 'wikilogy' ),
				'singular_name' => _x( 'Letters', 'Letters Singular Name', 'wikilogy' ),
				'menu_name' => esc_html__( 'Letters', 'wikilogy' ),
				'all_items' => esc_html__( 'All Letters', 'wikilogy' ),
				'parent_item' => esc_html__( 'Parent Letter', 'wikilogy' ),
				'parent_item_colon' => esc_html__( 'Parent Letter:', 'wikilogy' ),
				'new_item_name' => esc_html__( 'New Letter Name', 'wikilogy' ),
				'add_new_item' => esc_html__( 'Add New Letter', 'wikilogy' ),
				'edit_item' => esc_html__( 'Edit Letter', 'wikilogy' ),
				'view_item' => esc_html__( 'View Letter', 'wikilogy' ),
				'update_item' => esc_html__( 'Update Letter', 'wikilogy' ),
				'separate_items_with_commas' => esc_html__( 'Separate content letters with commas', 'wikilogy' ),
				'search_items' => esc_html__( 'Search Letters', 'wikilogy' ),
				'add_or_remove_items' => esc_html__( 'Add or remove content letters', 'wikilogy' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used content letters', 'wikilogy' ),
				'not_found' => esc_html__( 'Not Found', 'wikilogy' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
			);
			register_taxonomy( 'content_letter', array( 'content' ), $args );

		}
		add_action( 'init', 'content_letter', 0 );
	}



	/*====== Content Categories ======*/
	if ( ! function_exists( 'content_category' ) ) {
		function content_category() {
			$labels = array(
				'name' => _x( 'Categories', 'Categories General Name', 'wikilogy' ),
				'singular_name' => _x( 'Categories', 'Categories Singular Name', 'wikilogy' ),
				'menu_name' => esc_html__( 'Categories', 'wikilogy' ),
				'all_items' => esc_html__( 'All Categories', 'wikilogy' ),
				'parent_item' => esc_html__( 'Parent Category', 'wikilogy' ),
				'parent_item_colon' => esc_html__( 'Parent Category:', 'wikilogy' ),
				'new_item_name' => esc_html__( 'New Category Name', 'wikilogy' ),
				'add_new_item' => esc_html__( 'Add New Category', 'wikilogy' ),
				'edit_item' => esc_html__( 'Edit Category', 'wikilogy' ),
				'view_item' => esc_html__( 'View Category', 'wikilogy' ),
				'update_item' => esc_html__( 'Update Category', 'wikilogy' ),
				'separate_items_with_commas' => esc_html__( 'Separate content categories with commas', 'wikilogy' ),
				'search_items' => esc_html__( 'Search Categories', 'wikilogy' ),
				'add_or_remove_items' => esc_html__( 'Add or remove content categories', 'wikilogy' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used content categories', 'wikilogy' ),
				'not_found' => esc_html__( 'Not Found', 'wikilogy' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
			);
			register_taxonomy( 'content_category', array( 'content' ), $args );

		}
		add_action( 'init', 'content_category', 0 );
	}



/*======
*
* Shortcodes
*
======*/
	/*====== Tooltip ======*/
	function wikilogy_tooltip( $atts ) {
		$atts = shortcode_atts(
			array(
				'title' => '',
				'text' => '',
				'link' => '',
				'brackets' => '',
			),
			$atts
		);

		$output = "";

		if( !empty( $atts["title"] ) or !empty( $atts["text"] ) or !empty( $atts["link"] ) ) {
			$output .= '<a class="gt-ref-tooltip" href="' . esc_attr( $atts["link"] ) . '" data-toggle="tooltip" data-placement="bottom" title="' . esc_attr( $atts["text"] ) . '">';
				if( !$atts["brackets"] == "false" ) {
					$output .= '<span>[</span>';
				}
					$output .= esc_attr( $atts["title"] );
				if( !$atts["brackets"] == "false" ) {
					$output .= '<span>]</span>';
				}
			$output .= '<a>';
		}

		return $output;
	}
	add_shortcode( 'tooltip', 'wikilogy_tooltip' );



	/*====== Language Selector for Demo Header ======*/
	function wikilogy_demo_language_shortcode( $atts , $content = null ) {
		$atts = shortcode_atts(
			array(
				'wikilogy-demo-language' => '',
			), $atts
		);

		$output = '<div class="demo-language-selector">';
			$output .= '<ul>';
				$output .= '<li><a href="" data-toggle="tooltip" data-placement="bottom" title="' . esc_html__( 'English', 'wikilogy' ) . '">' . esc_html__( 'EN', 'wikilogy' ) . '</a></li>';
				$output .= '<li><a href="" data-toggle="tooltip" data-placement="bottom" title="' . esc_html__( 'Français', 'wikilogy' ) . '">' . esc_html__( 'FR', 'wikilogy' ) . '</a></li>';
				$output .= '<li><a href="" data-toggle="tooltip" data-placement="bottom" title="' . esc_html__( 'Deutsch', 'wikilogy' ) . '">' . esc_html__( 'DE', 'wikilogy' ) . '</a></li>';
				$output .= '<li><a href="" data-toggle="tooltip" data-placement="bottom" title="' . esc_html__( 'Espanol', 'wikilogy' ) . '">' . esc_html__( 'ES', 'wikilogy' ) . '</a></li>';
				$output .= '<li><a href="" data-toggle="tooltip" data-placement="bottom" title="' . esc_html__( 'Türkçe', 'wikilogy' ) . '">' . esc_html__( 'TR', 'wikilogy' ) . '</a></li>';
			$output .= '</ul>';
		$output .= '</div>';

		return $output;

	}
	add_shortcode( 'wikilogy_demo_language', 'wikilogy_demo_language_shortcode' );



/*======
*
* Elements for Page Builder
*
======*/
	/*====== Feature Box ======*/
	function wikilogy_feature_box_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'count' => '',
				'style' => '',
				'column' => '',
				'hover-effect' => '',
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Contents ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Contents ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Category Ids ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Column ======*/
		if( !empty( $atts['column'] ) ) {
			$column = $atts['column'];
		} else {
			$column = "4";
		}

		/*====== Style ======*/
		if( !empty( $atts['style'] ) ) {
			$style = $atts['style'];
		} else {
			$style = "style1";
		}

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arroıws ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Main Arg ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'content',
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Category Filter ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'content_category',
						'field' => 'term_id',
						'terms' => $category,
					),
				),
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			if( $style == "style2" ) {
				$output .= '<div class="feature-slider wikilogy-slider" data-item="' . esc_attr( $column ) . '" data-slidetoitem="' . esc_attr( $column ) . '" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
					while ( $wp_query->have_posts() ) {
						$wp_query->the_post();
						$output .= '<div class="item">';
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
						$output .= '</div>';
					}
					wp_reset_postdata();
				$output .= '</div>';
			} else {
				$output .= '<div class="feature-box column-' . esc_attr( $column ) . '">';
					while ( $wp_query->have_posts() ) {
						$wp_query->the_post();
						$output .= '<div class="item">';
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
							if( $atts["hover-effect"] == "true" ) {
								$output .= '<div class="hover">';
									if ( has_post_thumbnail() ) {
										$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-4' );
									} else {
										$image_url = "";
										$image_url[0] = "";
									}

									$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
										$output .= '<a href="' . get_the_permalink() . '"></a>';
										$output .= '<div class="inner">';
											$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
											if( !empty( $post_title_text ) ) {
												$output .= '<div class="title-text">' . $post_title_text . '</div>';
											}
											$output .= '<div class="title">' . get_the_title() . '</div>';
											$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "true", $category = "true", $date = "true", $style = "1" );
										$output .= '</div>';
									$output .= '</div>';
								$output .= '</div>';
							}
						$output .= '</div>';
					}
					wp_reset_postdata();
				$output .= '</div>';
			}
		}

		return $output;
	}
	add_shortcode( "wikilogy_feature_box", "wikilogy_feature_box_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Feature Box', 'wikilogy' ),
				"base" => "wikilogy_feature_box",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/feature-box.png',
				"description" =>esc_html__( 'Feature box element for the contents.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a content count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Style 1 - List', 'wikilogy' ) => 'style1',
							esc_html__( 'Style 2 - Carousel', 'wikilogy' ) => 'style2',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Column', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a column.', 'wikilogy' ),
						"param_name" => "column",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( '3', 'wikilogy' ) => '3',
							esc_html__( '4', 'wikilogy' ) => '4',
							esc_html__( '5', 'wikilogy' ) => '5',
							esc_html__( '6', 'wikilogy' ) => '6',
							esc_html__( '7', 'wikilogy' ) => '7',
							esc_html__( '8', 'wikilogy' ) => '8',
							esc_html__( '9', 'wikilogy' ) => '9',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Hover Effect', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a hover effect for the style 1.', 'wikilogy' ),
						"param_name" => "hover-effect",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay for the style 2.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
						"group" => esc_html__( 'Design', 'wikilogy' ),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow for the style 2.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite for the style 2.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Content List ======*/
	function wikilogy_content_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'count' => '',
				'style' => '',
				'column' => '',
				'image' => '',
				'excerpt' => '',
				'author' => '',
				'category_status' => '',
				'date' => '',
				'read-more' => '',
				'order-type' => '',
				'pagination' => '',
			), $atts
		);

		$output = "";

		/*====== Image ======*/
		if( !empty( $atts['image'] ) ) {
			$image = $atts['image'];
		} else {
			$image = "true";
		}

		/*====== Excerpt ======*/
		if( !empty( $atts['excerpt'] ) ) {
			$excerpt = $atts['excerpt'];
		} else {
			$excerpt = "true";
		}

		/*====== Author ======*/
		if( !empty( $atts['author'] ) ) {
			$author = $atts['author'];
		} else {
			$author = "true";
		}

		/*====== Category Status ======*/
		if( !empty( $atts['category_status'] ) ) {
			$category_status = $atts['category_status'];
		} else {
			$category_status = "true";
		}

		/*====== Date ======*/
		if( !empty( $atts['date'] ) ) {
			$date = $atts['date'];
		} else {
			$date = "true";
		}

		/*====== Read More ======*/
		if( !empty( $atts['read-more'] ) ) {
			$read_more = $atts['read-more'];
		} else {
			$read_more = "true";
		}

		/*====== Exclude Contents ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Contents ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Include Category ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Column ======*/
		if( !empty( $atts['column'] ) ) {
			$column = $atts['column'];
		} else {
			$column = "4";
		}

		/*====== Style ======*/
		if( !empty( $atts['style'] ) ) {
			$style = $atts['style'];
		} else {
			$style = "style1";
		}

		/*====== Popular Posts ======*/
		if( !empty( $atts['popular-posts'] ) ) {
			$popular_posts = $atts['popular-posts'];
		} else {
			$popular_posts = "true";
		}

		/*====== Paged ======*/
		$paged = is_front_page() ? get_query_var( 'page', 1 ) : get_query_var( 'paged', 1 );
		if( empty( $paged ) ) { $paged = 1; }

		/*====== Main Arg ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'content',
			'paged' => $paged,
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Category Filter ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'content_category',
						'field' => 'term_id',
						'terms' => $category,
					),
				),
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			$output .= '<div class="content-list column-' . esc_attr( $column ) . ' ' . $style . '">';
				$i = 0;
				while ( $wp_query->have_posts() ) {
					$i++;
					$wp_query->the_post();
					$output .= '<div class="item">';
						if( $atts['style'] == "style-1" ) {
							$output .= wikilogy_post_list_style_1( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-2" ) {
							$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-3" ) {
							$output .= wikilogy_post_list_style_3( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-4" ) {
							$output .= wikilogy_post_list_style_4( $post_id = get_the_ID(), $author = $author, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-5" ) {
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
						} elseif( $atts['style'] == "style-6" ) {
							$output .= wikilogy_post_list_style_6( $post_id = get_the_ID(), $image = $image, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-7" ) {
							$output .= wikilogy_post_list_style_7( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-8" ) {
							$output .= wikilogy_post_list_style_8( $post_id = get_the_ID(), $image = $image, $date = $date );
						} elseif( $atts['style'] == "style-9" ) {
							$output .= wikilogy_post_list_style_9( $post_id = get_the_ID(), $excerpt = $excerpt, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-10" ) {
							$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-11" ) {
							if( $i == "1" ) {
								$output .= wikilogy_post_list_style_3( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
							} else {
								$output .= wikilogy_post_list_style_6( $post_id = get_the_ID(), $image = $image, $category = $category_status, $date = $date );
							}
						} elseif( $atts['style'] == "style-12" ) {
							$output .= wikilogy_post_list_style_10( $post_id = get_the_ID(), $category = $category_status, $date = $date );
						}
					$output .= '</div>';
				}
				wp_reset_postdata();
			$output .= '</div>';

			if ( $atts['pagination'] == 'true' ) {
				$output .= wikilogy_element_pagination( $paged = $paged, $query = $wp_query );
			}
		}

		return $output;
	}
	add_shortcode( "wikilogy_content_list", "wikilogy_content_list_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Content List', 'wikilogy' ),
				"base" => "wikilogy_content_list",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/content-list.png',
				"description" =>esc_html__( 'Content list element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a content count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => 'style-1',
							esc_html__( 'Style 2', 'wikilogy' ) => 'style-2',
							esc_html__( 'Style 3', 'wikilogy' ) => 'style-3',
							esc_html__( 'Style 4', 'wikilogy' ) => 'style-4',
							esc_html__( 'Style 5', 'wikilogy' ) => 'style-5',
							esc_html__( 'Style 6', 'wikilogy' ) => 'style-6',
							esc_html__( 'Style 7', 'wikilogy' ) => 'style-7',
							esc_html__( 'Style 8', 'wikilogy' ) => 'style-8',
							esc_html__( 'Style 9', 'wikilogy' ) => 'style-9',
							esc_html__( 'Style 10', 'wikilogy' ) => 'style-10',
							esc_html__( 'Style 11', 'wikilogy' ) => 'style-11',
							esc_html__( 'Style 12', 'wikilogy' ) => 'style-12',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Column', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a column for the style 1, 2, 3, 4, 5, 6.', 'wikilogy' ),
						"param_name" => "column",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( '1', 'wikilogy' ) => '1',
							esc_html__( '2', 'wikilogy' ) => '2',
							esc_html__( '3', 'wikilogy' ) => '3',
							esc_html__( '4', 'wikilogy' ) => '4',
							esc_html__( '5', 'wikilogy' ) => '5',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Image', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the image for the style 1, 2, 3, 6, 7, 8, 10, 11.', 'wikilogy' ),
						"param_name" => "image",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Excerpt', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the excerpt for the style 1, 2, 3, 7, 9, 10, 11.', 'wikilogy' ),
						"param_name" => "excerpt",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Author', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the author for the style 1, 2, 3, 4, 7, 10, 11.', 'wikilogy' ),
						"param_name" => "author",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the category for the style 1, 2, 3, 4, 6, 7, 9, 10, 11, 12.', 'wikilogy' ),
						"param_name" => "category_status",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Date', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the date for the style 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12.', 'wikilogy' ),
						"param_name" => "date",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Read More Button', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the read more button for the style 1, 2, 3, 11, 10.', 'wikilogy' ),
						"param_name" => "read-more",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Pagination', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the pagination.', 'wikilogy' ),
						"param_name" => "pagination",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Content Slider ======*/
	function wikilogy_content_slider_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'count' => '',
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'date' => '',
				'category_status' => '',
				'author' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Contents ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Contents ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Include Category ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arrows ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Author ======*/
		if( !empty( $atts['author'] ) ) {
			$author = $atts['author'];
		} else {
			$author = "true";
		}

		/*====== Category Status ======*/
		if( !empty( $atts['category_status'] ) ) {
			$category_status = $atts['category_status'];
		} else {
			$category_status = "true";
		}

		/*====== Date ======*/
		if( !empty( $atts['date'] ) ) {
			$date = $atts['date'];
		} else {
			$date = "true";
		}

		/*====== Main Arg ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'content',
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Categories ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'content_category',
						'field' => 'term_id',
						'terms' => $category,
					),
				),
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Main Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			$output .= '<div class="content-slider wikilogy-slider" data-item="1" data-slidetoitem="1" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
				while ( $wp_query->have_posts() ) {
					$wp_query->the_post();
						if ( has_post_thumbnail() ) {
							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-8' );
						} else {
							$image_url = "";
							$image_url[0] = "";
						}

						$output .= '<div class="item">';
							$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
								$output .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0, 'post' => get_the_ID() ) ) . '"></a>';
								$output .= '<div class="inner">';
									$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
									if( !empty( $post_title_text ) ) {
										$output .= '<div class="title-text">' . $post_title_text . '</div>';
									}
									$output .= '<div class="title">' . get_the_title() . '</div>';
									$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = $author, $category = $category_status, $date = $date, $style = "1" );
								$output .= '</div>';
							$output .= '</div>';
						$output .= '</div>';
				}
				wp_reset_postdata();
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_content_slider", "wikilogy_content_slider_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Content Slider', 'wikilogy' ),
				"base" => "wikilogy_content_slider",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/content-slider.png',
				"description" =>esc_html__( 'Content slider element for the contents.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a content count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Author', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the author.', 'wikilogy' ),
						"param_name" => "author",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the category.', 'wikilogy' ),
						"param_name" => "category_status",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Date', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the date.', 'wikilogy' ),
						"param_name" => "date",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
						"group" => esc_html__( 'Design', 'wikilogy' ),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Letter List ======*/
	function wikilogy_letter_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'all-link-status' => '',
				'all-link' => '',
				'exclude-letters' => '',
				'include-letters' => '',
				'empty-taxonomies' => '',
				'childless' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Letters ======*/
		if( !empty( $atts['exclude-categories'] ) ) {
			$exclude_letters = $atts['exclude-categories'];
			$exclude_letters = explode( ',', $exclude_letters );
		} else {
			$exclude_letters = "";
		}

		/*====== Include Letters ======*/
		if( !empty( $atts['include-letters'] ) ) {
			$include_letters = $atts['include-letters'];
			$include_letters = explode( ',', $include_letters );
		} else {
			$include_letters = "";
		}

		/*====== Empty Letters ======*/
		if( $atts['empty-taxonomies'] == 'false' ) {
			$empty_taxonomies = false;
		} else {
			$empty_taxonomies = true;
		}

		/*====== Childless ======*/
		if( $atts['childless'] == 'false' ) {
			$childless = false;
		} else {
			$childless = true;
		}

		/*====== Style ======*/
		if( $atts["style"] == "style-2" ) {
			$style = " style-2";
		} else {
			$style = " style-1";
		}

		/*====== Tax Query ======*/
		$terms = get_terms(
			array(
				'taxonomy' => 'content_letter',
				'exclude' => $exclude_letters,
				'include' => $include_letters,
				'hide_empty' => $empty_taxonomies,
				'childless' => $childless,
			)
		);

		/*====== HTML Output ======*/
		if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
			$output .= '<div class="letters-list' . esc_attr( $style ) . '">';
				$output .= '<ul>';
					foreach ( $terms as $term ) {
						if( !empty( $term ) ) {
							$id = $term->term_id;
							$name = $term->name;
							$output .= '<li><a href="' . get_term_link( $id ) . '" title="' . esc_attr( $name ) . '">' . esc_attr( $name ) . '</a></li>';
						}
					}

					if( $atts["all-link-status"] == "true" ) {
						if( !empty( $atts["all-link"] ) ) {
							$link = $atts["all-link"];

							$link = vc_build_link( $link );
							if( !empty( $link["target"] ) ) {
								$link_target = $link["target"];
							} else {
								$link_target = "_parent";
							}

							if( !empty( $link["url"] ) ) {
								$output .= '<li><a href="' . esc_url( $link["url"] ) . '" title="' . esc_attr( $link["title"] ) . '" target="' . esc_attr( $link_target ) . '">' . esc_attr( $link["title"] ) . '</a></li>';
							}
						}
					}
				$output .= '</ul>';
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_letter_list", "wikilogy_letter_list_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Letter List', 'wikilogy' ),
				"base" => "wikilogy_letter_list",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/letter-list.jpg',
				"description" =>esc_html__( 'Letter list element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => 'style-1',
							esc_html__( 'Style 2', 'wikilogy' ) => 'style-2',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'All Link Status', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the all link.', 'wikilogy' ),
						"param_name" => "all-link-status",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__( 'All Link', 'wikilogy' ),
						"description" => esc_html__( 'You can create an all link.', 'wikilogy' ),
						"param_name" => "all-link",
						'save_always' => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Letters', 'wikilogy' ),
						"description" => esc_html__( 'You can enter letters ids. Separate with commas. Example: 1,2,3', 'wikilogy' ),
						"param_name" => "exclude-letters",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Letters', 'wikilogy' ),
						"description" => esc_html__( 'You can enter letters ids. Separate with commas. Example: 1,2,3', 'wikilogy' ),
						"param_name" => "include-letters",
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Empty Taxonomies', 'wikilogy' ),
						"description" => esc_html__( 'You can choose visible status of empty taxonomies. If you choose true option empty taxonomies will be hide.', 'wikilogy' ),
						"param_name" => "empty-taxonomies",
						"value" => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Childless', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of childless.', 'wikilogy' ),
						"param_name" => "childless",
						"value" => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== User List ======*/
	function wikilogy_user_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'exclude-users' => '',
				'include-users' => '',
				'roles' => '',
				'count' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Users ======*/
		if( !empty( $atts['exclude-users'] ) ) {
			$exclude_users = $atts['exclude-users'];
			$exclude_users = explode( ',', $exclude_users );
		} else {
			$exclude_users = "";
		}

		/*====== Include Users ======*/
		if( !empty( $atts['include-users'] ) ) {
			$include_users = $atts['include-users'];
			$include_users = explode( ',', $include_users );
		} else {
			$include_users = "";
		}

		/*====== Args ======*/
		$args = array(
			'include' => $include_users,
			'exclude' => $exclude_users,
			'orderby' => 'login',
			'order' => 'ASC',
			'number' => $atts["count"],
			'count_total' => false,
		);

		/*====== Role Filter ======*/
		if( !empty( $atts['roles'] ) ) {
			$roles = $atts['roles'];
			$roles = explode( ',', $roles );
			$role_arg = array(
				'role__in' => $roles,
			);
			$args = array_merge( $args, $role_arg );
		}

		/*====== HTML Output ======*/
		$users = get_users( $args );
		if( !empty( $users ) ) {
			$output .= '<div class="gt-user-list">';
				$output .= '<ul>';
					foreach ( $users as $user ) {
						if( !empty( $user ) ) {
							$user_info = get_userdata( esc_attr( $user->ID ) );
							$output .= '<li>';
								$output .= '<div class="image">';
									$output .= get_avatar( esc_attr( $user->ID, '150' ) );
								$output .= '</div>';
								$output .= '<div class="content">';
									$output .= '<div class="title">';
										$output .= '<a href="' . get_author_posts_url( esc_attr( $user->ID ) ) . '" title="' . esc_attr( $user->display_name ) . '">';
											$output .= esc_attr( $user->display_name );
										$output .= '</a>';
									$output .= '</div>';
									$output .= '<div class="excerpt">';
										$output .= implode( ', ', $user_info->roles );
									$output .= '</div>';
								$output .= '</div>';
							$output .= '</li>';
						}
					}
				$output .= '</ul>';
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_user_list", "wikilogy_user_list_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'User List', 'wikilogy' ),
				"base" => "wikilogy_user_list",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/user-list.jpg',
				"description" =>esc_html__( 'User list element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Users', 'wikilogy' ),
						"description" => esc_html__( 'You can enter users ids. Separate with commas. Example: 1,2,3', 'wikilogy' ),
						"param_name" => "exclude-users",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Users', 'wikilogy' ),
						"description" => esc_html__( 'You can enter users ids. Separate with commas. Example: 1,2,3', 'wikilogy' ),
						"param_name" => "include-users",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'User Roles', 'wikilogy' ),
						"description" => esc_html__( 'You can enter role names. Separate with commas. Example: editor,administrator etc. Do not enter a blank between roles.', 'wikilogy' ),
						"param_name" => "roles",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'User Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a user count.', 'wikilogy' ),
						"param_name" => "count",
						"admin_label" => true,
					),
				),
			)
		);
	}



	/*====== Blog Carousel ======*/
	function wikilogy_blog_carousel_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'count' => '',
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'date' => '',
				'category_status' => '',
				'author' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Posts ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Posts ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Include Category ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arrows ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Blog ======*/
		if( !empty( $atts['author'] ) ) {
			$author = $atts['author'];
		} else {
			$author = "true";
		}

		/*====== Category Status ======*/
		if( !empty( $atts['category_status'] ) ) {
			$category_status = $atts['category_status'];
		} else {
			$category_status = "true";
		}

		/*====== Date Status ======*/
		if( !empty( $atts['date'] ) ) {
			$date = $atts['date'];
		} else {
			$date = "true";
		}

		/*====== Main Query ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'post',
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Category ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'category',
						'field' => 'term_id',
						'terms' => $category,
					),
				),
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			$output .= '<div class="content-slider wikilogy-slider" data-item="1" data-slidetoitem="1" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
				while ( $wp_query->have_posts() ) {
					$wp_query->the_post();
						if ( has_post_thumbnail() ) {
							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-8' );
						} else {
							$image_url = "";
							$image_url[0] = "";
						}

						$output .= '<div class="item">';
							$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
								$output .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0, 'post' => get_the_ID() ) ) . '"></a>';
								$output .= '<div class="inner">';
									$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
									if( !empty( $post_title_text ) ) {
										$output .= '<div class="title-text">' . $post_title_text . '</div>';
									}
									$output .= '<div class="title">' . get_the_title() . '</div>';
									$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = $author, $category = $category_status, $date = $date, $style = "1" );
								$output .= '</div>';
							$output .= '</div>';
						$output .= '</div>';
				}
				wp_reset_postdata();
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_blog_carousel", "wikilogy_blog_carousel_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Blog Carousel', 'wikilogy' ),
				"base" => "wikilogy_blog_carousel",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/blog-carousel.png',
				"description" =>esc_html__( 'Blog carousel element for posts.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter content ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a content count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Author', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the author.', 'wikilogy' ),
						"param_name" => "author",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the category.', 'wikilogy' ),
						"param_name" => "category_status",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Date', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the date.', 'wikilogy' ),
						"param_name" => "date",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
						"group" => esc_html__( 'Design', 'wikilogy' ),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Blog Tabs ======*/
	function wikilogy_blog_tabs_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'title' => '',
				'include-categories' => '',
				'exclude-categories' => '',
				'tag' => '',
				'contentids' => '',
				'exclude-posts' => '',
				'hide-empty' => '',
				'childs' => '',
				'all-tab' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Posts ======*/
		if( !empty( $atts['exclude-posts'] ) ) {
			$excludecontents = $atts['exclude-posts'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Hide Empty ======*/
		if( $atts["hide-empty"] == "true" ) {
			$hide_empty = "true";
		} else {
			$hide_empty = "";
		}

		/*====== Childs ======*/
		if( $atts["childs"] == "true" ) {
			$childs = "";
		} else {
			$childs = "0";
		}

		/*====== Include Categories ======*/
		if( !empty( $atts['include-categories'] ) ) {
			$includecategories = $atts['include-categories'];
			$includecategories = explode( ',', $includecategories );
		} else {
			$includecategories = "";
		}

		/*====== Exclude Categories ======*/
		if( !empty( $atts['exclude-categories'] ) ) {
			$excludecategory = $atts['exclude-categories'];
			$excludecategory = explode( ',', $excludecategory );
		} else {
			$excludecategory = "";
		}

		/*====== HTML Output ======*/
		$output .= '<div class="blog-tabs">';
			$arg = array(
				'taxonomy' => 'category',
				'hide_empty' => $hide_empty,
				'exclude' => $excludecategory,
				'include' => $includecategories,
				'parent' => $childs,
				'hierarchical' => true,
			);

			$terms = get_terms( $arg );
			if( !empty( $terms ) ) {
				$output .= '<ul class="tab-list nav nav-tabs" role="tablist">';
					$i = "";
					$output .= '<li class="title">' . $atts["title"] . '</li>';
					if( $atts["all-tab"] == "true" ) {
						$output .= '<li class="nav-item">';
							$output .= '<a id="blog-tab-all-tab" data-toggle="tab" href="#blog-tab-all" role="tab" aria-controls="blog-tab-all">' . esc_html__( 'All', 'wikilogy' ) . '</a>';
						$output .= '</li>';
					}
					foreach ( $terms as $term ) {
						if( !empty( $term ) ) {
							$name = $term->name;
							$slug = $term->slug;
							$id = $term->term_id;
							$output .= '<li>';
								$output .= '<a id="blog-tab-' . $slug . '-tab" data-toggle="tab" href="#blog-tab-' . $slug . '" role="tab" aria-controls="blog-tab-' . $slug . '">' . $name . '</a>';
							$output .= '</li>';
						}
					}
				$output .= '</ul>';

				$output .= '<div class="tab-content">';
					if( $atts["all-tab"] == "true" ) {
						$output .= '<div class="tab-pane fade" id="blog-tab-all" role="tabpanel" aria-labelledby="blog-tab-all">';
							$output .= '<div class="content">';
								$output .= '<div class="left">';
									$arg = array(
										'posts_per_page' => '1',
										'offset' => 0,
										'tag' => $tag,
										'post_status' => 'publish',
										'post__not_in' => $exclude,
										'ignore_sticky_posts' => true,
										'post_type' => 'post',
									);
									$wp_query = new WP_Query( $arg );
									if ( $wp_query->have_posts() ) {
										while ( $wp_query->have_posts() ) {
											$wp_query->the_post();
											$output .= wikilogy_post_list_style_3( $post_id = get_the_ID(), $image = "true", $excerpt = "true", $author = "true", $category = "true", $date = "true", $read_more = "false" );
										}
									}
									wp_reset_postdata();
								$output .= '</div>';
								$output .= '<div class="right">';
									$arg = array(
										'posts_per_page' => '3',
										'offset' => 1,
										'tag' => $tag,
										'post_status' => 'publish',
										'post__not_in' => $exclude,
										'ignore_sticky_posts' => true,
										'post_type' => 'post',
									);
									$wp_query = new WP_Query( $arg );
									if ( $wp_query->have_posts() ) {
										while ( $wp_query->have_posts() ) {
											$wp_query->the_post();
											$output .= wikilogy_post_list_style_8( $post_id = get_the_ID(), $image = "true", $date = "true" );
										}
									}
									wp_reset_postdata();
								$output .= '</div>';
							$output .= '</div>';
						$output .= '</div>';							
					}

					foreach ( $terms as $term ) {
						if( !empty( $term ) ) {
							$name = $term->name;
							$slug = $term->slug;
							$id = $term->term_id;
							$output .= '<div class="tab-pane fade" id="blog-tab-' . $slug . '" role="tabpanel" aria-labelledby="blog-tab-' . $slug . '">';
								$output .= '<div class="content">';
									$output .= '<div class="left">';
										$arg = array(
											'posts_per_page' => '1',
											'offset' => 0,
											'tag' => $tag,
											'cat' => $id,
											'post_status' => 'publish',
											'post__not_in' => $exclude,
											'ignore_sticky_posts' => true,
											'post_type' => 'post',
										);
										$wp_query = new WP_Query( $arg );
										if ( $wp_query->have_posts() ) {
											while ( $wp_query->have_posts() ) {
												$wp_query->the_post();
												$output .= wikilogy_post_list_style_3( $post_id = get_the_ID(), $image = "true", $excerpt = "true", $author = "true", $category = "true", $date = "true", $read_more = "false" );
											}
										}
										wp_reset_postdata();
									$output .= '</div>';
									$output .= '<div class="right">';
										$arg = array(
											'posts_per_page' => '3',
											'offset' => 1,
											'tag' => $tag,
											'cat' => $id,
											'post_status' => 'publish',
											'post__not_in' => $exclude,
											'ignore_sticky_posts' => true,
											'post_type' => 'post',
										);
										$wp_query = new WP_Query( $arg );
										if ( $wp_query->have_posts() ) {
											while ( $wp_query->have_posts() ) {
												$wp_query->the_post();
												$output .= wikilogy_post_list_style_8( $post_id = get_the_ID(), $image = "true", $date = "true" );
											}
										}
										wp_reset_postdata();
									$output .= '</div>';
								$output .= '</div>';
							$output .= '</div>';
						}
					}
				$output .= '</div>';
			}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "wikilogy_blog_tabs", "wikilogy_blog_tabs_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Blog Tabs', 'wikilogy' ),
				"base" => "wikilogy_blog_tabs",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/blog-tabs.png',
				"description" =>esc_html__( 'Blog tabs element for posts.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Title', 'wikilogy' ),
						"description" => esc_html__( 'You can enter the title.', 'wikilogy' ),
						"param_name" => "title",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Categories', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "include-categories",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Categories', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "exclude-categories",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "exclude-posts",
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Hide Empty', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the empty categories.', 'wikilogy' ),
						"param_name" => "hide-empty",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Childs', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the child categories.', 'wikilogy' ),
						"param_name" => "childs",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'All Tab', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the all tab.', 'wikilogy' ),
						"param_name" => "all-tab",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Blog Slider ======*/
	function wikilogy_blog_slider_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'side-count' => '',
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Posts ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Posts ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Include Categories ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arrows ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Slide Count ======*/
		if( !empty( $atts["slide-count"] ) ) {
			$count = $atts["slide-count"] * 4;
		} else {
			$count = "8";
		}

		/*====== Main Arg ======*/
		$arg = array(
			'posts_per_page' => $count,
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'post',
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Category ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'cat' => $category,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			$output .= '<div class="blog-slider wikilogy-slider" data-item="1" data-slidetoitem="1" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
				$i = 0; 
				while ( $wp_query->have_posts() ) : $wp_query->the_post();
					$counter = range(0, 200, 4);
						if (in_array($i, $counter)) {
							$output .= '<div class="item">';
							$output .= '<div class="left">';
								if ( has_post_thumbnail() ) {
									$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-8' );
								} else {
									$image_url = "";
									$image_url[0] = "";
								}						
								$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
									$output .= '<a href="' . get_the_permalink() . '"></a>';
									$output .= '<div class="inner">';
										$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
										if( !empty( $post_title_text ) ) {
											$output .= '<div class="title-text">' . $post_title_text . '</div>';
										}
										$output .= '<div class="title">' . get_the_title() . '</div>';
										$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "true", $category = "true", $date = "true", $style = "1" );
									$output .= '</div>';
								$output .= '</div>';
							$output .= '</div>';
						}
						elseif (in_array($i + 3, $counter)) {
							$output .= '<div class="right">';
								$output .= '<div class="top">';
									if ( has_post_thumbnail() ) {
										$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-4' );
									} else {
										$image_url = "";
										$image_url[0] = "";
									}						
									$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
										$output .= '<a href="' . get_the_permalink() . '"></a>';
										$output .= '<div class="inner">';
											$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
											if( !empty( $post_title_text ) ) {
												$output .= '<div class="title-text">' . $post_title_text . '</div>';
											}
											$output .= '<div class="title">' . get_the_title() . '</div>';
											$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "true", $category = "true", $date = "true", $style = "1" );
										$output .= '</div>';
									$output .= '</div>';
								$output .= '</div>';
						}
						elseif (in_array($i + 2, $counter)) {
							$output .= '<div class="bottom">';
							$output .= '<div class="left">';
								if ( has_post_thumbnail() ) {
									$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-2' );
								} else {
									$image_url = "";
									$image_url[0] = "";
								}						
								$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
									$output .= '<a href="' . get_the_permalink() . '"></a>';
									$output .= '<div class="inner">';
										$output .= '<div class="title">' . get_the_title() . '</div>';
										$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "false", $category = "true", $date = "true", $style = "1" );
									$output .= '</div>';
								$output .= '</div>';
							$output .= '</div>';
						}
						else {
							$output .= '<div class="right">';
								if ( has_post_thumbnail() ) {
									$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-2' );
								} else {
									$image_url = "";
									$image_url[0] = "";
								}						
								$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
									$output .= '<a href="' . get_the_permalink() . '"></a>';
									$output .= '<div class="inner">';
										$output .= '<div class="title">' . get_the_title() . '</div>';
										$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "false", $category = "true", $date = "true", $style = "1" );
									$output .= '</div>';
								$output .= '</div>';
							$output .= '</div>';
							$output .= '</div>';
							$output .= '</div>';
						}
					if (in_array($i + 1, $counter)) {
						$output .= '</div>';
					}
					
				$i++; endwhile;
				wp_reset_postdata();
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_blog_slider", "wikilogy_blog_slider_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Blog Slider', 'wikilogy' ),
				"base" => "wikilogy_blog_slider",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/blog-slider.png',
				"description" =>esc_html__( 'Blog slider element for posts.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Contents', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Slide Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a slide count.', 'wikilogy' ),
						"param_name" => "side-count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay for the style 2.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
						"group" => esc_html__( 'Design', 'wikilogy' ),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Blog Box ======*/
	function wikilogy_blog_box_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'contentids' => '',
				'excludecontents' => '',
				'offset' => '',
				'count' => '',
				'style' => '',
				'column' => '',
				'hover-effect' => '',
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Exclude Posts ======*/
		if( !empty( $atts['excludecontents'] ) ) {
			$excludecontents = $atts['excludecontents'];
			$exclude = explode( ',', $excludecontents );
		} else {
			$exclude = "";
		}

		/*====== Include Posts ======*/
		if( !empty( $atts['contentids'] ) ) {
			$contentids = $atts['contentids'];
			$include_posts = explode( ',', $contentids );
		} else {
			$include_posts = "";
		}

		/*====== Include Categories ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Column ======*/
		if( !empty( $atts['column'] ) ) {
			$column = $atts['column'];
		} else {
			$column = "4";
		}

		/*====== Style ======*/
		if( !empty( $atts['style'] ) ) {
			$style = $atts['style'];
		} else {
			$style = "style1";
		}

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arrows ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Main Query ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'post',
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Category ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'cat' => $category,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			if( $style == "style2" ) {
				$output .= '<div class="feature-slider wikilogy-slider" data-item="' . esc_attr( $column ) . '" data-slidetoitem="' . esc_attr( $column ) . '" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
					while ( $wp_query->have_posts() ) {
						$wp_query->the_post();
						$output .= '<div class="item">';
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
						$output .= '</div>';
					}
					wp_reset_postdata();
				$output .= '</div>';
			} else {
				$output .= '<div class="feature-box column-' . esc_attr( $column ) . '">';
					while ( $wp_query->have_posts() ) {
						$wp_query->the_post();
						$output .= '<div class="item">';
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
							if( $atts["hover-effect"] == "true" ) {
								$output .= '<div class="hover">';
									if ( has_post_thumbnail() ) {
										$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'wikilogy-post-4' );
									} else {
										$image_url = "";
										$image_url[0] = "";
									}

									$output .= '<div class="content" style="background-image:url(' . esc_url( $image_url[0] ) . ');">';
										$output .= '<a href="' . get_the_permalink() . '"></a>';
										$output .= '<div class="inner">';
											$post_title_text = get_post_meta( get_the_ID(), 'title_text', true );
											if( !empty( $post_title_text ) ) {
												$output .= '<div class="title-text">' . $post_title_text . '</div>';
											}
											$output .= '<div class="title">' . get_the_title() . '</div>';
											$output .= wikilogy_post_information( $post_id = get_the_ID(), $author = "true", $category = "true", $date = "true", $style = "1" );
										$output .= '</div>';
									$output .= '</div>';
								$output .= '</div>';
							}
						$output .= '</div>';
					}
					wp_reset_postdata();
				$output .= '</div>';
			}
		}

		return $output;
	}
	add_shortcode( "wikilogy_blog_box", "wikilogy_blog_box_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Blog Box', 'wikilogy' ),
				"base" => "wikilogy_blog_box",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/blog-box.png',
				"description" =>esc_html__( 'Blog box element for posts.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "contentids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecontents",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Post Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a post count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1 - List', 'wikilogy' ) => 'style1',
							esc_html__( 'Style 2 - Carousel', 'wikilogy' ) => 'style2',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Column', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a column.', 'wikilogy' ),
						"param_name" => "column",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( '3', 'wikilogy' ) => '3',
							esc_html__( '4', 'wikilogy' ) => '4',
							esc_html__( '5', 'wikilogy' ) => '5',
							esc_html__( '6', 'wikilogy' ) => '6',
							esc_html__( '7', 'wikilogy' ) => '7',
							esc_html__( '8', 'wikilogy' ) => '8',
							esc_html__( '9', 'wikilogy' ) => '9',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Hover Effect', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a hover effect for the style 1.', 'wikilogy' ),
						"param_name" => "hover-effect",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay for the style 2.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
						"group" => esc_html__( 'Design', 'wikilogy' ),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow for the style 2.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite for the style 2.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Blog List ======*/
	function wikilogy_blog_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'tag' => '',
				'postids' => '',
				'excludeposts' => '',
				'offset' => '',
				'count' => '',
				'style' => '',
				'column' => '',
				'image' => '',
				'excerpt' => '',
				'author' => '',
				'category_status' => '',
				'date' => '',
				'read-more' => '',
				'pagination' => '',
				'order-type' => '',
			), $atts
		);

		$output = "";

		/*====== Image ======*/
		if( !empty( $atts['image'] ) ) {
			$image = $atts['image'];
		} else {
			$image = "true";
		}

		/*====== Excerpt ======*/
		if( !empty( $atts['excerpt'] ) ) {
			$excerpt = $atts['excerpt'];
		} else {
			$excerpt = "true";
		}

		/*====== Author Status ======*/
		if( !empty( $atts['author'] ) ) {
			$author = $atts['author'];
		} else {
			$author = "true";
		}

		/*====== Category Status ======*/
		if( !empty( $atts['category_status'] ) ) {
			$category_status = $atts['category_status'];
		} else {
			$category_status = "true";
		}

		/*====== Date Status ======*/
		if( !empty( $atts['date'] ) ) {
			$date = $atts['date'];
		} else {
			$date = "true";
		}

		/*====== Read More Status ======*/
		if( !empty( $atts['read-more'] ) ) {
			$read_more = $atts['read-more'];
		} else {
			$read_more = "true";
		}

		/*====== Exclude Posts ======*/
		if( !empty( $atts['excludeposts'] ) ) {
			$excludeposts = $atts['excludeposts'];
			$exclude = explode( ',', $excludeposts );
		} else {
			$exclude = "";
		}

		/*====== Include Posts ======*/
		if( !empty( $atts['postids'] ) ) {
			$postids = $atts['postids'];
			$include_posts = explode( ',', $postids );
		} else {
			$include_posts = "";
		}

		/*====== Include Category ======*/
		if( !empty( $atts['category'] ) ) {
			$category = $atts['category'];
			$category = explode( ',', $category );
		} else {
			$category = "";
		}

		/*====== Tag ======*/
		if( !empty( $atts['tag'] ) ) {
			$tag = $atts['tag'];
		} else {
			$tag = "";
		}

		/*====== Column ======*/
		if( !empty( $atts['column'] ) ) {
			$column = $atts['column'];
		} else {
			$column = "4";
		}

		/*====== Style ======*/
		if( !empty( $atts['style'] ) ) {
			$style = $atts['style'];
		} else {
			$style = "style1";
		}

		/*====== Pagination Status ======*/
		if ( $atts['pagination'] == 'true' ) {
			$pagination_status = "pagination-active";
		} else {
			$pagination_status = "";
		}

		/*====== Paged ======*/
		$paged = is_front_page() ? get_query_var( 'page', 1 ) : get_query_var( 'paged', 1 );
		if( empty( $paged ) ) { $paged = 1; }

		/*====== Main ======*/
		$arg = array(
			'posts_per_page' => $atts['count'],
			'offset' => $atts['offset'],
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'post',
			'paged' => $paged,
		);

		/*====== Tag ======*/
		if( !empty( $tag ) ) {
			$extra_query = array(
				'tag' => $tag
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Posts ======*/
		if( !empty( $include_posts ) ) {
			$extra_query = array(
				'post__in' => $include_posts,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Exclude Posts ======*/
		if( !empty( $exclude ) ) {
			$extra_query = array(
				'post__not_in' => $exclude,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Include Category ======*/
		if( !empty( $category ) ) {
			$extra_query = array(
				'cat' => $category,
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Order Type ======*/
		if( $atts["order-type"] == "popular" ) {
			$extra_query = array(
				'orderby' => 'comment_count',
			);
			$arg = wp_parse_args( $arg, $extra_query );
		}

		/*====== Query ======*/
		$wp_query = new WP_Query( $arg );

		/*====== HTML Output ======*/
		if ( $wp_query->have_posts() ) {
			$output .= '<div class="content-list column-' . esc_attr( $column ) . ' ' . $style . ' ' . $pagination_status . '">';
				$i = 0;
				while ( $wp_query->have_posts() ) {
					$i++;
					$wp_query->the_post();
					$output .= '<div class="item">';
						if( $atts['style'] == "style-1" ) {
							$output .= wikilogy_post_list_style_1( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-2" ) {
							$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-3" ) {
							$output .= wikilogy_post_list_style_3( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-4" ) {
							$output .= wikilogy_post_list_style_4( $post_id = get_the_ID(), $author = $author, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-5" ) {
							$output .= wikilogy_post_list_style_5( $post_id = get_the_ID(), $top_text = "true" );
						} elseif( $atts['style'] == "style-6" ) {
							$output .= wikilogy_post_list_style_6( $post_id = get_the_ID(), $image = $image, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-7" ) {
							$output .= wikilogy_post_list_style_7( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-8" ) {
							$output .= wikilogy_post_list_style_8( $post_id = get_the_ID(), $image = $image, $date = $date );
						} elseif( $atts['style'] == "style-9" ) {
							$output .= wikilogy_post_list_style_9( $post_id = get_the_ID(), $excerpt = $excerpt, $category = $category_status, $date = $date );
						} elseif( $atts['style'] == "style-10" ) {
							$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
						} elseif( $atts['style'] == "style-11" ) {
							if( $i == "1" ) {
								$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
							} else {
								$output .= wikilogy_post_list_style_6( $post_id = get_the_ID(), $image = $image, $category = $category_status, $date = $date );
							}
						} elseif( $atts['style'] == "style-12" ) {
							$output .= wikilogy_post_list_style_10( $post_id = get_the_ID(), $category = $category_status, $date = $date );
						
						} elseif( $atts['style'] == "style-13" ) {
							if( $i == "1" ) {
								$output .= wikilogy_post_list_style_2( $post_id = get_the_ID(), $image = $image, $excerpt = $excerpt, $author = $author, $category = $category_status, $date = $date, $read_more = $read_more );
							} else {
								$output .= wikilogy_post_list_style_8( $post_id = get_the_ID(), $image = $image, $date = $date );
							}
						}
					$output .= '</div>';
				}
				wp_reset_postdata();
			$output .= '</div>';

			if ( $atts['pagination'] == 'true' ) {
				$output .= wikilogy_element_pagination( $paged = $paged, $query = $wp_query );
			}
		}

		return $output;
	}
	add_shortcode( "wikilogy_blog_list", "wikilogy_blog_list_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Blog List', 'wikilogy' ),
				"base" => "wikilogy_blog_list",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/blog-list.png',
				"description" =>esc_html__( 'Blog list element for the posts.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "category",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Tag', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a tag.', 'wikilogy' ),
						"param_name" => "tag",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "postids",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Posts', 'wikilogy' ),
						"description" => esc_html__( 'You can enter post ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludeposts",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Offset', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an offset number.', 'wikilogy' ),
						"param_name" => "offset",
						"group" => esc_html__( 'General', 'wikilogy' ),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Post Count', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a post count.', 'wikilogy' ),
						"param_name" => "count",
						"group" => esc_html__( 'General', 'wikilogy' ),
						"admin_label" => true,
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Order Type', 'wikilogy' ),
						"description" => esc_html__( 'You can choose an order type.', 'wikilogy' ),
						"param_name" => "order-type",
						'save_always' => true,
						"group" => esc_html__( 'General', 'wikilogy' ),
						'value' => array(
							esc_html__( 'Newest', 'wikilogy' ) => 'newest',
							esc_html__( 'Popular', 'wikilogy' ) => 'popular',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => 'style-1',
							esc_html__( 'Style 2', 'wikilogy' ) => 'style-2',
							esc_html__( 'Style 3', 'wikilogy' ) => 'style-3',
							esc_html__( 'Style 4', 'wikilogy' ) => 'style-4',
							esc_html__( 'Style 5', 'wikilogy' ) => 'style-5',
							esc_html__( 'Style 6', 'wikilogy' ) => 'style-6',
							esc_html__( 'Style 7', 'wikilogy' ) => 'style-7',
							esc_html__( 'Style 8', 'wikilogy' ) => 'style-8',
							esc_html__( 'Style 9', 'wikilogy' ) => 'style-9',
							esc_html__( 'Style 10', 'wikilogy' ) => 'style-10',
							esc_html__( 'Style 11', 'wikilogy' ) => 'style-11',
							esc_html__( 'Style 12', 'wikilogy' ) => 'style-12',
							esc_html__( 'Style 13', 'wikilogy' ) => 'style-13',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Column', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a column for the style 1, 2, 3, 4, 5, 6.', 'wikilogy' ),
						"param_name" => "column",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						"admin_label" => true,
						'value' => array(
							esc_html__( '1', 'wikilogy' ) => '1',
							esc_html__( '2', 'wikilogy' ) => '2',
							esc_html__( '3', 'wikilogy' ) => '3',
							esc_html__( '4', 'wikilogy' ) => '4',
							esc_html__( '5', 'wikilogy' ) => '5',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Image', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the image for the style 1, 2, 3, 6, 7, 8, 10, 11.', 'wikilogy' ),
						"param_name" => "image",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Excerpt', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the excerpt for the style 1, 2, 3, 7, 9, 10, 11.', 'wikilogy' ),
						"param_name" => "excerpt",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Author', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the author for the style 1, 2, 3, 4, 7, 10, 11.', 'wikilogy' ),
						"param_name" => "author",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Category', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the category for the style 1, 2, 3, 4, 6, 7, 9, 10, 11, 12.', 'wikilogy' ),
						"param_name" => "category_status",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Date', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the date for the style 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12.', 'wikilogy' ),
						"param_name" => "date",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Read More Button', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the read more button for the style 1, 2, 3, 11, 10.', 'wikilogy' ),
						"param_name" => "read-more",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Pagination', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the pagination.', 'wikilogy' ),
						"param_name" => "pagination",
						'save_always' => true,
						"group" => esc_html__( 'Design', 'wikilogy' ),
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}



	/*====== Category List ======*/
	function wikilogy_category_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'taxonomy' => '',
				'includecategories' => '',
				'excludecategories' => '',
				'style' => '',
				'hide-empty' => '',
				'childs' => '',
				'all-categories-link' => '',
			), $atts
		);

		$output = "";

		if( !empty( $atts["taxonomy"] ) ) {

			/*====== Taxonomy ======*/
			if( $atts["taxonomy"] == "content-categories" ) {
				$taxonomy = "content_category";
			} else {
				$taxonomy = "category";
			}

			/*====== Style ======*/
			if( $atts["style"] == "style-2" ) {
				$style = " style-2";
			} else {
				$style = " style-1";
			}

			/*====== Hide Empty ======*/
			if( $atts["hide-empty"] == "true" ) {
				$hide_empty = "true";
			} else {
				$hide_empty = "";
			}

			/*====== Childs ======*/
			if( $atts["childs"] == "true" ) {
				$childs = "";
			} else {
				$childs = "0";
			}

			/*====== Include Categories ======*/
			if( !empty( $atts['includecategories'] ) ) {
				$includecategories = $atts['includecategories'];
				$include = explode( ',', $includecategories );
			} else {
				$include = "";
			}

			/*====== Exclude Categories ======*/
			if( !empty( $atts['excludecategories'] ) ) {
				$excludecategories = $atts['excludecategories'];
				$exclude = explode( ',', $excludecategories );
			} else {
				$exclude = "";
			}

			/*====== Main Arg ======*/
			$arg = array(
				'taxonomy' => $taxonomy,
				'hide_empty' => $hide_empty,
				'exclude' => $exclude,
				'include' => $include,
				'parent' => $childs,
				'hierarchical' => true,
			);

			/*====== HTML Output ======*/
			$terms = get_terms( $arg );
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$output .= '<ul class="category-list' . $style . '">';
					foreach ( $terms as $term ) {
						if( !empty( $term ) ) {
							if( $term->parent == 0 ) {
								$name = $term->name;
								$id = $term->term_id;
								$output .= '<li><a class="main-title" href="' . get_term_link( $id ) . '" title="' . $name . '">' . $name . '</a>';
									if( $atts["childs"] == "true" ) {
										if( $term->parent == 0 ) {
											$output .= '<ul class="child-1">';
										}
											foreach( $terms as $sub_term ) {
												if(	$sub_term->parent == $term->term_id	) {
													$sub_name = $sub_term->name;
													$sub_id = $sub_term->term_id;
													$output .= '<li class="sub-item">';
														$output .= '<a href="' . get_term_link( $sub_id ) . '" title="' . $sub_name . '">' . $sub_name . '</a>';
														if( $sub_term->parent == 2 ) {
															$output .= '<ul class="child-2">';
														}
															foreach( $terms as $sub_term1 ) {
																if(	$sub_term1->parent == $sub_term->term_id ) {
																	$sub_name = $sub_term1->name;
																	$sub_id = $sub_term1->term_id;
																	$output .= '<li class="sub-item"><a href="' . get_term_link( $sub_id ) . '" title="' . $sub_name . '">' . $sub_name . '</a>';

																	$output .= '</li>';
																}
															}
														if( $sub_term->parent == 2 ) {
															$output .= '</ul>';
														}
													$output .= '</li>';
												}
											}
										if( $term->parent == 0 ) {
											$output .= '</ul>';
										}
									}
								$output .= '</li>';
							}
						}
					}

					if( !empty( $atts["all-categories-link"] ) ) {
						$href = $atts["all-categories-link"];
						$href = vc_build_link( $href );
						if( !empty( $href["target"] ) ) {
							$target = $href["target"];
						} else {
							$target = "_parent";
						}
						if( !empty( $href["title"] ) or !empty( $href["url"] ) ) {
							$output .= '<li><a href="' . esc_url( $href["url"] ) . '" target="' . esc_attr( $target ) . '" title="' . esc_attr( $href["title"] ) . '">' . esc_attr( $href["title"] ) . '</a></li>';
						}
					}
				$output .= '</ul>';
			}
		}

		return $output;
	}
	add_shortcode( "wikilogy_category_list", "wikilogy_category_list_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Category List', 'wikilogy' ),
				"base" => "wikilogy_category_list",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/category-list.png',
				"description" =>esc_html__( 'Category list element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Taxonomy', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a taxonomy.', 'wikilogy' ),
						"param_name" => "taxonomy",
						"admin_label" => true,
						'save_always' => true,
						'value' => array(
							esc_html__( 'Post Categories', 'wikilogy' ) => 'post-categories',
							esc_html__( 'Content Categories', 'wikilogy' ) => 'content-categories',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Include Categories', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "includecategories",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Exclude Categories', 'wikilogy' ),
						"description" => esc_html__( 'You can enter category ids. Separate with commas 1,2,3 etc.', 'wikilogy' ),
						"param_name" => "excludecategories",
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => 'style-1',
							esc_html__( 'Style 2', 'wikilogy' ) => 'style-2',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Hide Empty', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the empty categories.', 'wikilogy' ),
						"param_name" => "hide-empty",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Childs', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the child categories.', 'wikilogy' ),
						"param_name" => "childs",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__( 'All Categories Link', 'wikilogy' ),
						"description" => esc_html__( 'You can create a all categories link.', 'wikilogy' ),
						"param_name" => "all-categories-link",
						'save_always' => true,
					),
				),
			)
		);
	}



	/*====== Search Form ======*/
	function wikilogy_search_form_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'description' => '',
				'style2-image' => '',
				'style3-images' => '',
				'autoplay-speed' => '',
			), $atts
		);

		$output = "";

		/*====== Style ======*/
		if( !empty( $atts["style"] ) ) {
			$style = ' ' . $atts["style"];
		} else {
			$style = " style-1";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts["autoplay-speed"] ) ) {
			$autoplay_speed = $atts["autoplay-speed"];
		} else {
			$autoplay_speed = "5000";
		}

		/*====== HTML Output ======*/
		$output .= '<div class="wikilogy-search-form' . $style . '">';
			if( $atts["style"] == "style-1" or $atts["style"] == "style-4" ) {
				$output .= wikilogy_search_form();
				if( !empty( $atts["description"] ) ) {
					$output .= '<p class="description">' . $atts["description"] . '</p>';
				}
			} elseif( $atts["style"] == "style-2" ) {
				if( !empty( $atts["style2-image"] ) ) {
					$background_image = $atts["style2-image"];
				} else {
					$background_image = "";
				}

				$output .= '<div class="background" style="background-image:url(' . esc_url( wp_get_attachment_url( $background_image, 'full', true, true ) ) . ');">';
					$output .= wikilogy_search_form();
					if( !empty( $atts["description"] ) ) {
						$output .= '<p class="description">' . $atts["description"] . '</p>';
					}
				$output .= '</div>';
			} elseif( $atts["style"] == "style-3" ) {
				if( !empty( $atts["style3-images"] ) ) {
					$bg_ids = explode( ',', $atts["style3-images"] ); 
				} else {
					$bg_ids = "";
				}

				if( !empty( $bg_ids ) ) {
					$output .= '<div class="wikilogy-slider" data-item="1" data-dots="false" data-arrows="false" data-fade="true" data-autoplay="true" data-autospeed="' . esc_attr( $autoplay_speed ) . '">';
						foreach( $bg_ids as $bg ) {
							if( !empty( $bg ) ) {
								$output .= '<div class="item" style="background-image:url(' . esc_url( wp_get_attachment_url( $bg, 'wikilogy-full', true, true ) ) . ');"></div>';

							}
						}
					$output .= '</div>';

					$output .= '<div class="content">';
						$output .= wikilogy_search_form();
						if( !empty( $atts["description"] ) ) {
							$output .= '<p class="description">' . $atts["description"] . '</p>';
						}
					$output .= '</div>';
				}
			}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "wikilogy_search_form", "wikilogy_search_form_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Search Form', 'wikilogy' ),
				"base" => "wikilogy_search_form",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/search-form.png',
				"description" =>esc_html__( 'Search form element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => 'style-1',
							esc_html__( 'Style 2', 'wikilogy' ) => 'style-2',
							esc_html__( 'Style 3', 'wikilogy' ) => 'style-3',
							esc_html__( 'Style 4', 'wikilogy' ) => 'style-4',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Description', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a description text for under the form.', 'wikilogy' ),
						"param_name" => "description",
					),
					array(
						"type" => "attach_image",
						"heading" => esc_html__( 'Background Image for the style 2', 'wikilogy' ),
						"description" => esc_html__( 'You can upload a background image for the style 2.', 'wikilogy' ),
						"param_name" => "style2-image",
					),
					array(
						"type" => "attach_images",
						"heading" => esc_html__( 'Background Images for Style 3', 'wikilogy' ),
						"description" => esc_html__( 'You can upload background images for the style 3.', 'wikilogy' ),
						"param_name" => "style3-images",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed for the style 3. Default: 5000', 'wikilogy' ),
						"param_name" => "autoplay-speed",
					),
				),
			)
		);
	}



	/*====== Search Form ======*/
	function wikilogy_title_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'title' => '',
				'title-text' => '',
				'shadow-text' => '',
			), $atts
		);

		$output = "";

		if( $atts["title"] ) {

			/*====== Shadow Text ======*/
			if( $atts["shadow-text"] ) {
				$shadow_text = $atts["shadow-text"];
			} else {
				$shadow_text = "";
			}

			/*====== Title ======*/
			if( $atts["title-text"] ) {
				$title_text = $atts["title-text"];
			} else {
				$title_text = "";
			}

			/*====== Style ======*/
			if( $atts["style"] ) {
				$style = $atts["style"];
			} else {
				$style = "1";
			}

			/*====== HTML Output ======*/
			$output .= wikilogy_title( $title = $atts["title"], $shadow_title = $shadow_text, $text = $title_text, $style = $style );
		}

		return $output;
	}
	add_shortcode( "wikilogy_title", "wikilogy_title_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Title', 'wikilogy' ),
				"base" => "wikilogy_title",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/title.png',
				"description" =>esc_html__( 'Title element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Style', 'wikilogy' ),
						"description" => esc_html__( 'You can choose a style.', 'wikilogy' ),
						"param_name" => "style",
						'save_always' => true,
						"admin_label" => true,
						'value' => array(
							esc_html__( 'Style 1', 'wikilogy' ) => '1',
							esc_html__( 'Style 2', 'wikilogy' ) => '2',
							esc_html__( 'Style 3', 'wikilogy' ) => '3',
							esc_html__( 'Style 4', 'wikilogy' ) => '4',
							esc_html__( 'Style 5', 'wikilogy' ) => '5',
							esc_html__( 'Style 6', 'wikilogy' ) => '6',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Title', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a title.', 'wikilogy' ),
						"param_name" => "title",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Title Text', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a title text for the style 1, style 2 and style 3.', 'wikilogy' ),
						"param_name" => "title-text",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Shadow Text', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a shadow text for the style 1, style 2 and style 3.', 'wikilogy' ),
						"param_name" => "shadow-text",
					),
				),
			)
		);
	}



	/*====== History Table ======*/
	function wikilogy_history_table_output( $atts, $content = null ) {		
		$atts = shortcode_atts(
			array(
				'title' => '',
				'titletext' => '',
			), $atts
		);

		$output = '';

		/*====== HTML Output ======*/
		$output .= '<div class="history-table">';
			if( !empty( $atts["title"] ) ) {
				$output .= wikilogy_title( $title = $atts["title"], $shadow_title = "", $text = $atts["titletext"], $style = "3" );
			}
			$output .= '<ul>';
				$output .= do_shortcode( $content );
			$output .= '</ul>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "wikilogy_history_table", "wikilogy_history_table_output" );

	function wikilogy_history_table_item_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'contentid' => '',
				'image' => '',
				'date' => '',
				'link' => '',
				'title' => '',
				'text' => '',
			), $atts
		);
		
		$output = '';

		/*====== HTML Output ======*/
		if( !empty( $atts["contentid"] ) or !empty( $atts["image"] ) or !empty( $atts["date"] ) or !empty( $atts["link"] ) or !empty( $atts["title"] ) or !empty( $atts["text"] ) ) {
			$output .= '<li>';
				$href = $atts["link"];
				$href = vc_build_link( $href );
				if( !empty( $atts["contentid"] ) ) {
					if( !empty( $atts["image"] ) ) {
						if ( has_post_thumbnail( $atts["contentid"] ) ) {
							$output .= '<div class="image">';
								if( !empty( $href["url"] ) ) {
									$output .= '<a href="' . $href["url"] . '">';
								}
									$output .= '<img src="' . wp_get_attachment_url( $atts["image"], 'thumbnail', true, true ) . '" />';

								if( !empty( $href["url"] ) ) {
									$output .= '</a>';
								}
							$output .= '</div>';
						}
					} else {
						if ( has_post_thumbnail( $atts["contentid"] ) ) {
							$output .= '<div class="image">';
								$output .= '<a href="' . get_the_permalink( $atts["contentid"] ) . '" title="' . the_title_attribute( array( 'echo' => 0, 'post' => $atts["contentid"] ) ) . '">';
									$output .= get_the_post_thumbnail( $atts["contentid"], 'thumbnail' );
								$output .= '</a>';
							$output .= '</div>';
						}
					}
					$output .= '<div class="content">';
						$output .= '<div class="title">';
							$history_date = get_post_meta( $atts["contentid"], 'content_history_table', true );
							if( !empty( $atts["date"] ) ) {
								$output .= '<span class="date">' . $atts["date"] . ' - </span>';
							} elseif( !empty( $history_date ) ) {
								$global_date = wikilogy_global_date_converter( $date = $history_date );
								$output .= '<span class="date">' . date( 'Y', strtotime( $global_date ) ) . ' - </span>';
							}

							if( !empty( $atts["title"] ) and !empty( $href["url"] ) ) {
								$output .= '<a href="' . $href["url"] . '">' . $atts["title"] . '</a>';	
							} else {
								$output .= '<a href="' . get_the_permalink( $atts["contentid"] ) . '" title="' . the_title_attribute( array( 'echo' => 0, 'post' => $atts["contentid"] ) ) . '">' . get_the_title( $atts["contentid"] ) . '</a>';								
							}
						$output .= '</div>';

						$excerpt = get_the_excerpt( $atts["contentid"] );
						if( !empty( $atts["text"] ) ) {
							$output .= '<div class="excerpt">' . $atts["text"] . '</div>';
						} elseif( !empty( $excerpt ) ) {
							$output .= '<div class="excerpt">' . get_the_excerpt( $atts["contentid"] ) . '</div>';
						}
					$output .= '</div>';
				}
			$output .= '</li>';
		}

		return $output;
	}
	add_shortcode("wikilogy_history_table_item", "wikilogy_history_table_item_shortcode");

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'History Table', 'wikilogy' ),
				"base" => "wikilogy_history_table",
				"as_parent" => array( "only" => "wikilogy_history_table_item" ),
				"js_view" => "VcColumnView",
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/history-table.png',
				"description" =>esc_html__( 'History table element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Title', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a title.', 'wikilogy' ),
						"param_name" => "title",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Description Text', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a description text.', 'wikilogy' ),
						"param_name" => "titletext",
					),
				)
			)
		);
	}

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'History Table Item', 'wikilogy' ),
				"base" => "wikilogy_history_table_item",
				"as_child" => array( "only" => "wikilogy_history_table" ),
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/history-table.png',
				"description" =>esc_html__( 'History table item element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content ID', 'wikilogy' ),
						"description" => esc_html__( 'If it is a content, you can enter content ID. If it is not a content you can enter a link.', 'wikilogy' ),
						"param_name" => "contentid",
						"admin_label" => true,
					),
					array(
						"type" => "attach_image",
						"class" => "",
						"heading" => esc_html__( 'Custom Image', 'wikilogy'),
						"description" => esc_html__( 'You can a upload image.', 'wikilogy'),
						"param_name" => "image",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Custom Date', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a date.', 'wikilogy' ),
						"param_name" => "date",
					),
					array(
						"type" => "vc_link",
						"heading" => esc_html__( 'Custom Link', 'wikilogy' ),
						"description" => esc_html__( 'You can createa a link.', 'wikilogy' ),
						"param_name" => "link",
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Custom Title', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a custom title.', 'wikilogy' ),
						"param_name" => "title",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Custom Text', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a custom text.', 'wikilogy' ),
						"param_name" => "text",
					),
				)
			)
		);
	}

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_wikilogy_history_table extends WPBakeryShortCodesContainer {}
	}



	/*====== Text Slider ======*/
	function wikilogy_text_slider_output( $atts, $content = null ) {		
		$atts = shortcode_atts(
			array(
				'autoplay' => '',
				'autoplay-speed' => '',
				'arrows' => '',
				'infinite' => '',
				'dots' => '',
			), $atts
		);

		$output = '';

		/*====== Autoplay ======*/
		if( !empty( $atts['autoplay'] ) ) {
			$autoplay = $atts['autoplay'];
		} else {
			$autoplay = "true";
		}

		/*====== Autoplay Speed ======*/
		if( !empty( $atts['autoplay-speed'] ) ) {
			$autoplay_speed = $atts['autoplay-speed'];
		} else {
			$autoplay_speed = "7000";
		}

		/*====== Arrows ======*/
		if( !empty( $atts['arrows'] ) ) {
			$arrows = $atts['arrows'];
		} else {
			$arrows = "true";
		}

		/*====== Infinite ======*/
		if( !empty( $atts['infinite'] ) ) {
			$infinite = $atts['infinite'];
		} else {
			$infinite = "true";
		}

		/*====== Dots ======*/
		if( !empty( $atts['dots'] ) ) {
			$dots = $atts['dots'];
		} else {
			$dots = "true";
		}

		/*====== Pagination Buttons ======*/
		$prev_button = '<div class="prev arrow"><i class="fas fa-chevron-left"></i></div>';
		$next_button = '<div class="next arrow"><i class="fas fa-chevron-right"></i></div>';

		/*====== HTML Output ======*/
		$output .= '<div class="text-slider">';
			$output .= '<div class="wikilogy-slider" data-item="1" data-slidetoitem="1" data-autoplay="' . $autoplay . '" data-autospeed="' . $autoplay_speed . '" data-arrows="' . $arrows . '" data-infinite="' . $infinite . '" data-dots="' . $dots . '" data-prevarrow="' . esc_attr( $prev_button ) . '" data-nextarrow="' . esc_attr( $next_button ) . '">';
					$output .= do_shortcode( $content );
			$output .= '</div>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "wikilogy_text_slider", "wikilogy_text_slider_output" );

	function wikilogy_text_slider_item_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'content' => '',
			), $atts
		);
		
		$output = '';

		/*====== Content ======*/
		$atts['content'] = $content;

		/*====== HTML Output ======*/
		if( !empty( $atts["content"] ) ) {
			$output .= '<div class="item">';
				if( !empty( $atts["content"] ) ) {
					$output .= wpautop( $atts["content"] );
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode("wikilogy_text_slider_item", "wikilogy_text_slider_item_shortcode");

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Text Slider', 'wikilogy' ),
				"base" => "wikilogy_text_slider",
				"as_parent" => array( "only" => "wikilogy_text_slider_item" ),
				"js_view" => "VcColumnView",
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/history-table.png',
				"description" =>esc_html__( 'Text slider element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Autoplay', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the autoplay.', 'wikilogy' ),
						"param_name" => "autoplay",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Autoplay Speed', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an autoplay speed.', 'wikilogy' ),
						"param_name" => "autoplay-speed",
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Arrows', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the arrow.', 'wikilogy' ),
						"param_name" => "arrows",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Dots', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the dots.', 'wikilogy' ),
						"param_name" => "dots",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Infinite', 'wikilogy' ),
						"description" => esc_html__( 'You can choose status of the infinite.', 'wikilogy' ),
						"param_name" => "infinite",
						'save_always' => true,
						'value' => array(
							esc_html__( 'True', 'wikilogy' ) => 'true',
							esc_html__( 'False', 'wikilogy' ) => 'false',
						),
					),
				),
			)
		);
	}

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Text Slider Item', 'wikilogy' ),
				"base" => "wikilogy_text_slider_item",
				"as_child" => array( "only" => "wikilogy_text_slider" ),
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/text-slider.png',
				"description" =>esc_html__( 'Text slider item element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textarea_html",
						"heading" => esc_html__( 'Text', 'wikilogy' ),
						"admin_label" => true,
						"description" => esc_html__( 'You can enter custom text.', 'wikilogy' ),
						"param_name" => "content",
					),
				)
			)
		);
	}

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_wikilogy_text_slider extends WPBakeryShortCodesContainer {}
	}



	/*====== Video / Audio Player ======*/
	function wikilogy_video_audio_element_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'contenttype' => '',
				'videoid' => '',
				'html5link' => '',
				'posterimage' => '',
			), $atts
		);
		
		$output = '';

		/*====== HTML Output ======*/
		if( !empty( $atts["videoid"] ) or !empty( $atts["html5link"] ) ) {
			$output .= '<div class="wikilogy-video-audio-element">';

				/*====== Vimeo ======*/
				if( $atts["contenttype"] == "vimeo" ) {
					if( !empty( $atts["videoid"] ) ) {
						$output .= '<div data-type="vimeo" data-video-id="' . esc_attr( $atts["videoid"] ) . '"></div>';
					}

				/*====== HTML5 Video ======*/
				} elseif( $atts["contenttype"] == "html5video" ) {
					if( !empty( $atts["html5link"] ) ) {
						$output .= '<video poster="' . esc_url( wp_get_attachment_url( esc_attr( $atts["posterimage"] ), 'full', true, true ) ) . '" controls>
										<source src="' . esc_url( $atts["html5link"] ) . '" type="video/mp4">
									</video>';
					}

				/*====== HTML5 Audio ======*/
				} elseif( $atts["contenttype"] == "html5audio" ) {
					if( !empty( $atts["html5link"] ) ) {
						$output .= '<audio controls>
										<source src="' . esc_url( $atts["html5link"] ) . '" type="audio/mp3">
									</audio>';
					}

				/*====== YouTube ======*/
				} else {
					if( !empty( $atts["videoid"] ) ) {
						$output .= '<div data-type="youtube" data-video-id="' . esc_attr( $atts["videoid"] ) . '"></div>';
					}
				}

			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_video_audio_element", "wikilogy_video_audio_element_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Video / Audio Player', 'wikilogy' ),
				"base" => "wikilogy_video_audio_element",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/wikilogy-video-audio-element.png',
				"description" =>esc_html__( 'Video / audio player element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "dropdown",
						"heading" => esc_html__( 'Content Type', 'wikilogy' ),
						"description" => esc_html__( 'You can select content type.', 'wikilogy' ),
						"param_name" => "contenttype",
						"admin_label" => true,
						'save_always' => true,
						'value' => array(
							esc_html__( 'YouTube', 'wikilogy' ) => 'youtube',
							esc_html__( 'Vimeo', 'wikilogy' ) => 'vimeo',
							esc_html__( 'HTML5 Video', 'wikilogy' ) => 'html5video',
							esc_html__( 'HTML5 Audio', 'wikilogy' ) => 'html5audio',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Video ID for YouTube / Video', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a video id for YouTube / Vimeo.', 'wikilogy' ),
						"param_name" => "videoid",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Video / Audio Link for HTML5', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a video / audio link for HTML5 player.', 'wikilogy' ),
						"param_name" => "html5link",
					),
					array(
						"type" => "attach_image",
						"class" => "",
						"heading" => esc_html__( 'Video Poster for HTML5 Video', 'wikilogy' ),
						"description" => esc_html__( 'You can upload a poster image for HTML5 video.', 'wikilogy'),
						"param_name" => "posterimage",
					),
				),
			)
		);
	}



	/*====== Content Table ======*/
	function wikilogy_content_table_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'id' => '',
			), $atts
		);

		$output = "";

		/*====== ID ======*/
		if( !empty( $atts['id'] ) ) {
			$id = $atts['id'];
		} else {
			$id = get_the_ID();
		}

		/*====== HTML Output ======*/
		$output .= wikilogy_content_table( $post_id = $id );

		return $output;
	}
	add_shortcode( "wikilogy_content_table", "wikilogy_content_table_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Content Table', 'wikilogy' ),
				"base" => "wikilogy_content_table",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/content-table.png',
				"description" =>esc_html__( 'Content table element for contents.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Content ID', 'wikilogy' ),
						"admin_label" => true,
						"description" => esc_html__( 'You can enter a content ID. If you this page is A content detail page, don not enter a ID.', 'wikilogy' ),
						"param_name" => "id",
					),
				),
			)
		);
	}



	/*====== Contact Box ======*/
	function wikilogy_contact_box_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'address' => '',
				'email' => '',
				'phone' => '',
				'fax' => '',
			), $atts
		);
		
		$output = '';

		/*====== HTML Output ======*/
		if( !empty( $atts["address"] ) or !empty( $atts["email"] ) or !empty( $atts["phone"] ) or !empty( $atts["fax"] ) or !empty( $atts["abouttext"] ) or !empty( $atts["aboutlink"] ) ) {
			$output .= '<div class="wikilogy-contact-box">';
				if( !empty( $atts["address"] ) ) {
					$output .= '<div class="contact-row address"><i class="fas fa-map-marker-alt"></i>' . esc_attr( $atts["address"] ) . '</div>';
				}

				if( !empty( $atts["email"] ) ) {
					$output .= '<div class="contact-row email"><i class="fas fa-envelope"></i><a href="mailto:' . esc_attr( str_replace(' ', '', $atts["email"] ) ) . '">' . esc_attr( $atts["email"] ) . '</a></div>';
				}

				if( !empty( $atts["phone"] ) ) {
					$output .= '<div class="contact-row phone"><i class="fas fa-phone"></i><a href="tel:+' . esc_attr( str_replace(' ', '', $atts["phone"] ) ) . '">' . esc_attr( $atts["phone"] ) . '</a></div>';
				}

				if( !empty( $atts["fax"] ) ) {
					$output .= '<div class="contact-row fax"><i class="fas fa-fax"></i>' . esc_attr( $atts["fax"] ) . '</div>';
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "wikilogy_contact_box", "wikilogy_contact_box_output" );

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Contact Box', 'wikilogy' ),
				"base" => "wikilogy_contact_box",
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/contact-box.png',
				"description" =>esc_html__( 'Contact Box element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Address', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an address.', 'wikilogy' ),
						"param_name" => "address",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Email', 'wikilogy' ),
						"description" => esc_html__( 'You can enter an email address.', 'wikilogy' ),
						"param_name" => "email",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Phone', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a phone number.', 'wikilogy' ),
						"param_name" => "phone",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Fax', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a fax number.', 'wikilogy' ),
						"param_name" => "fax",
						"admin_label" => true,
					),
				),
			)
		);
	}



	/*====== Icon List ======*/
	function wikilogy_icon_list_output( $atts, $content = null ) {		
		$atts = shortcode_atts(
			array(
				'style' => '',
			), $atts
		);

		$output = '';

		/*====== HTML Output ======*/
		$output .= '<div class="wikilogy-icon-list ' . esc_attr( $atts["style"] ) . '">';
			$output .= '<ul>';
				$output .= do_shortcode( $content );
			$output .= '</ul>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "wikilogy_icon_list", "wikilogy_icon_list_output" );

	function wikilogy_icon_list_item_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'text' => '',
				'icon' => '',
			), $atts
		);
		
		$output = '';

		/*====== HTML Output ======*/
		if( !empty( $atts["text"] ) ) {
			$output .= '<li>';
				if( !empty( $atts["icon"] ) ) {
					$output .= '<i class="' . esc_attr( $atts["icon"] ) . '" aria-hidden="true"></i>';
				}
				if( !empty( $atts["text"] ) ) {
					$output .= '<div class="text">' . esc_attr( $atts["text"] ) . '</div>';
				}
			$output .= '</li>';
		}

		return $output;
	}
	add_shortcode("wikilogy_icon_list_item", "wikilogy_icon_list_item_shortcode");

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Icon List', 'wikilogy' ),
				"base" => "wikilogy_icon_list",
				"as_parent" => array( "only" => "wikilogy_icon_list_item" ),
				"js_view" => "VcColumnView",
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/icon-list.png',
				"description" =>esc_html__( 'Icon List element.', 'wikilogy' ),
			)
		);
	}

	if( function_exists( 'vc_map' ) ) {
		vc_map(
			array(
				"name" => esc_html__( 'Icon List Item', 'wikilogy' ),
				"base" => "wikilogy_icon_list_item",
				"as_child" => array( "only" => "wikilogy_icon_list" ),
				"content_element" => true,
				"category" => esc_html__( 'Wikilogy Theme', 'wikilogy' ),
				"icon" => get_template_directory_uri() . '/include/assets/img/icons/wikilogy-icon-list.png',
				"description" =>esc_html__( 'Icon list item element.', 'wikilogy' ),
				"params" => array(
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Text', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a text.', 'wikilogy' ),
						"param_name" => "text",
						"admin_label" => true,
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__( 'Icon', 'wikilogy' ),
						"description" => esc_html__( 'You can enter a link icon. Example: fab fa-wordpress-simple, fas fa-map-marker-alt. Icon list: https://goo.gl/vdPEsc', 'wikilogy' ),
						"param_name" => "icon",
					),
				)
			)
		);
	}

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_wikilogy_icon_list extends WPBakeryShortCodesContainer {}
	}